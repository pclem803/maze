//
//  definitions.h
//  Maze Game
//
//  Created by Philip Clement on 7/29/19.
//  Copyright © 2019 Philip Clement. All rights reserved.
//

const int UP = 0;
const int RIGHT = 1;
const int LEFT = 2;
const int DOWN = 3;
