//
//  block.cpp
//  Maze Game
//
//  Created by Philip Clement on 7/29/19.
//  Copyright © 2019 Philip Clement. All rights reserved.
//

#include "block.hpp"
#include <iostream>

using namespace std;


//----------STACKS---------//


stacknode::stacknode(block cell){
    data=cell;
    next=NULL;
}

stack::stack(){
    top=NULL;
}

stack::~stack(){
    while (top!=NULL){
        stacknode* temp=top->next;
        delete top;
        top=temp;
    }
}
    
void stack::push(block cell){
    stacknode* newnode= new stacknode(cell);
    if (top==NULL)
        top=newnode;
    else{
        stacknode* previous_top = top;
        top=newnode;
        top->next=previous_top;
    }
}

block stack::pop(){ //remove top item
    stacknode* removing_node=top;
    block item = top->data;
    top=top->next;
    delete removing_node;
    return item;
}

block stack::peek(){//shows top item
    return top->data;
}
bool stack::isEmpty(){
    if (top==NULL)
        return 1;
    else
        return 0;
}



//----------QUEUES---------//




queuenode::queuenode(block d){
    data=d;
    next=NULL;
}

queue::queue(){
    first=NULL;
    last=NULL;
}

queue::~queue(){
    while(first!=NULL){
        if (first==last){
            delete first;
        }
        else{
            queuenode* tempnode = first->next;
            delete first;
            first=tempnode;
        }
    }
}


void queue::add(block d){
    queuenode* new_node= new queuenode(d);
    if (first==NULL){//empty queue
        first=new_node;
        last=new_node;
    }
    else if (first==last){//if only one element in queue
        last= new_node;
    }
    else{//more that one element in the queue;
        queuenode* temp_node= last;
        last=new_node;
        temp_node->next=last;
    }
}


block queue::remove(){
    block return_block=first->data;
    queuenode* temp_node;
    if (first==last){
        delete first;
        return return_block;
    }
    else{
        temp_node=first;
        first=first->next;
        delete temp_node;
        return return_block;
    }
}

block queue::peek(){
    return first->data;
}

bool queue::isEmpty(){
    if (first==NULL)
        return true;
    else
        return false;
}
